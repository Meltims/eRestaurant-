package com.example.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.myapplication.foodMenuPack.FoodMenu;
import com.example.myapplication.tableBookingPack.TableBookingForm;

public class MainActivity extends AppCompatActivity {
    private Button btn_tabBook;
    private Button btn_foodMenu;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        btn_tabBook = (Button) findViewById(R.id.main_btn_book_table);
        btn_tabBook.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openTabBooking();
            }
        });

        btn_foodMenu = (Button) findViewById(R.id.main_btn_food_menu);
        btn_foodMenu.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                openFoodMenu();
            }
        });
    }

    public void openTabBooking() {
        Intent intent = new Intent (this, TableBookingForm.class);
        startActivity(intent);
    }

    public void openFoodMenu() {
        Intent intent = new Intent (this, FoodMenu.class);
        startActivity(intent);
    }
}