package com.example.myapplication.foodMenuPack;

public class Food {
    private String foodName;
    private String description;
    private String price;
    private int image;

    public Food(String foodName, String description, String price, int image) {
        this.foodName = foodName;
        this.description = description;
        this.price = price;
        this.image = image;
    }

    public String getFoodName() {
        return foodName;
    }

    public void setFoodName(String foodName) {
        this.foodName = foodName;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getPrice() {
        return price;
    }

    public void setPrice(String price) {
        this.price = price;
    }

    public int getImage() {
        return image;
    }

    public void setImage(int image) {
        this.image = image;
    }
}
