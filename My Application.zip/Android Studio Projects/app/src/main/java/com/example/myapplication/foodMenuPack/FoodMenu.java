package com.example.myapplication.foodMenuPack;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.RecyclerView;

import android.os.Bundle;
import android.widget.ListView;

import com.example.myapplication.R;

import java.util.ArrayList;

public class FoodMenu extends AppCompatActivity {

    ListView lvFood;
    ArrayList<Food> arrayFood;
    FoodAdapter adapter;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_food_menu);

        control();

        adapter = new FoodAdapter(this, R.layout.layout_food, arrayFood);
        lvFood.setAdapter(adapter);

    }

    private void control() {
        lvFood = (ListView) findViewById(R.id.lv_food_menu);

        arrayFood = new ArrayList<>();
        arrayFood.add(new Food("Chicken Fried Rice", "Chicken fried rice is the comfort dish of Chinese food. The dish started as way to use leftover fried rice that has dried out some and may not be great...", "$14.00", R.drawable.ckfriedrice));
        arrayFood.add(new Food("Pho", "A Vietnamese soup is normally made with a bone-beef broth, banh pho noodles, and thinly sliced beef, that's often served with bean sprouts...", "$14.00", R.drawable.pho));
    }


}